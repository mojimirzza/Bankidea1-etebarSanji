import json, os, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import stage2_agent
from stage2_tools import get_temporal_activity, get_reversal_analysis, get_data_quality_report, get_dimension_distribution, execute_tool

class Stage2Tests(unittest.TestCase):
    def test_temporal_tool_detects_count_difference_for_selected_customer(self):
        result = get_temporal_activity("SYN-CUST-0067")
        self.assertEqual(result["first_half_txn_count"], 28)
        self.assertEqual(result["second_half_txn_count"], 14)
        self.assertEqual(result["count_comparison_label"], "FEWER_ROWS_IN_SECOND_CALENDAR_HALF")

    def test_reversal_tool_returns_expected_observed_markers(self):
        result = get_reversal_analysis("SYN-CUST-0064")
        self.assertEqual(result["reversal_count"], 3)
        self.assertEqual(len(result["example_rows_max_10"]), 3)
        self.assertTrue(all("pan" not in r for r in result["example_rows_max_10"]))

    def test_quality_tool_checks_duplicate_refs_without_pan(self):
        result = get_data_quality_report("SYN-CUST-0001")
        self.assertEqual(result["duplicate_refnum_row_count"], 0)
        self.assertEqual(result["invalid_amount_count"], 0)
        self.assertNotIn("pan", result)

    def test_dimension_allowlist(self):
        result = get_dimension_distribution("SYN-CUST-0001", "server_name")
        self.assertEqual(result["distinct_value_count"], 3)
        with self.assertRaises(ValueError):
            get_dimension_distribution("SYN-CUST-0001", "pan")

    def test_tool_cannot_change_customer(self):
        with self.assertRaises(ValueError):
            execute_tool("get_temporal_activity", {"customer_id": "SYN-CUST-0002"}, "SYN-CUST-0001")

    def test_python_router_has_some_question_conditioning(self):
        q = "این پرونده را از منظر تداوم استفاده مرور کن؛ آیا پراکندگی رویدادها در بازهٔ مشاهده‌شده یکنواخت بوده؟"
        self.assertIn("get_temporal_activity", stage2_agent.route_question_python(q))
        q2 = "سلامت ورودی‌ها و احتمال شناسه‌های تکراری را وارسی کن"
        self.assertIn("get_data_quality_report", stage2_agent.route_question_python(q2))

    def test_response_validator_accepts_supported_evidence_refs(self):
        case = stage2_agent.get_case("temporal_continuity")
        tool_results = {"get_temporal_activity": {"first_half_txn_count": 28, "second_half_txn_count": 14}}
        payload = {
            "case_id": case["case_id"], "customer_id": case["customer_id"], "interpreted_goal": "Temporal review",
            "selected_tools": ["get_temporal_activity"],
            "findings": [{"statement": "The first half had more rows.", "evidence_refs": ["get_temporal_activity.first_half_txn_count", "get_temporal_activity.second_half_txn_count"]}],
            "limitations": ["Observed activity only."], "recommended_next_step": "Check repayment history separately.",
            "review_outcome": "HUMAN_REVIEW_REQUIRED"
        }
        self.assertEqual(stage2_agent.validate_response(payload, case, tool_results), [])

    def test_api_flow_is_max_two_requests_and_supports_multiple_tools(self):
        case = stage2_agent.get_case("temporal_continuity")
        c_id = case["customer_id"]
        first = {"id": "r1", "model": "demo/model", "choices": [{"message": {"content": None, "tool_calls": [
            {"id": "c1", "type": "function", "function": {"name": "get_temporal_activity", "arguments": json.dumps({"customer_id": c_id})}},
            {"id": "c2", "type": "function", "function": {"name": "get_activity_summary", "arguments": json.dumps({"customer_id": c_id})}}
        ]}}], "usage": {"prompt_tokens": 20, "completion_tokens": 10, "total_tokens": 30}}
        payload = {"case_id": case["case_id"], "customer_id": c_id, "interpreted_goal": "Temporal review",
            "selected_tools": ["get_temporal_activity", "get_activity_summary"],
            "findings": [
                {"statement": "Activity differs by half.", "evidence_refs": ["get_temporal_activity.first_half_txn_count", "get_temporal_activity.second_half_txn_count"]},
                {"statement": "The number of observed rows is available.", "evidence_refs": ["get_activity_summary.txn_count"]}
            ],
            "limitations": ["This is not repayment evidence."], "recommended_next_step": "Review independent repayment history.",
            "review_outcome": "HUMAN_REVIEW_REQUIRED"}
        second = {"id": "r2", "model": "demo/model", "choices": [{"message": {"content": json.dumps(payload)}}], "usage": {"prompt_tokens": 30, "completion_tokens": 20, "total_tokens": 50}}
        with tempfile.TemporaryDirectory() as td, patch.object(stage2_agent, "_post", side_effect=[first, second]) as post, patch.dict(os.environ, {"LLM_API_KEY": "dummy"}):
            out = Path(td) / "result.json"
            result = stage2_agent.run_live("temporal_continuity", output_path=out)
            self.assertTrue(out.exists())
        self.assertEqual(post.call_count, 2)
        self.assertEqual(result["structural_and_evidence_reference_validation"]["status"], "PASS")
        self.assertEqual(result["agent_tool_score"]["required_tool_recall"], 1.0)
        self.assertEqual(len(result["agent_tool_score"]["executed_tools"]), 2)
        tool_messages = [m for m in post.call_args_list[1].args[0]["messages"] if m.get("role") == "tool"]
        self.assertEqual(len(tool_messages), 2)

if __name__ == "__main__":
    unittest.main()
