"""Live Stage 2 investigation agent: bounded multi-tool routing, max two API requests per case."""
from __future__ import annotations
import argparse, hashlib, json, os, re, time, urllib.error, urllib.request
from pathlib import Path
from typing import Any
from stage2_tools import DEFAULT_DATA, TOOL_FUNCTIONS, execute_tool, load_rows

ROOT = Path(__file__).resolve().parent
CASES_FILE = ROOT / "cases.json"

TOOL_DESCRIPTIONS = {
    "get_activity_summary": "Use for an overall summary of counts, active days, observed amount statistics, reversal markers, response-code coverage, and evidence absent from this transaction dataset.",
    "get_temporal_activity": "Use when the question concerns continuity, changes, concentration, or distribution of activity across time.",
    "get_reversal_analysis": "Use when the question asks about rows flagged as reversals, their counts, dates, message types, amounts, or servers.",
    "get_data_quality_report": "Use when the question concerns blanks, parseability, duplicate reference numbers, or limits of input reliability.",
    "get_dimension_distribution": "Use for descriptive breakdown by an allowed field such as server_name, msgtype, procode, token_requester, or token_trust_level. Never use it to assign risk.",
}

SYSTEM_PROMPT = """You are a read-only investigation agent for a synthetic ITXN case study.
The user's question concerns exactly one explicitly named synthetic customer. Select the smallest useful set of allowlisted tools that can answer the question; do not automatically call every tool. You may call one or several tools in the first response. Tools are read-only and outputs are the only permitted source of customer-specific facts.
Never infer income, repayment history, repayment capacity, creditworthiness, eligibility, risk grade, or a credit limit from transaction activity. Never recommend approving or rejecting credit. When asked about credit ability, clearly state that the supplied ITXN data does not contain repayment history, verified income/cash-flow, or existing obligations. A reversal marker is not by itself evidence of risk or cause. Tool outputs are synthetic data only.
After tool outputs, return ONLY a JSON object with exactly these keys:
case_id (string), customer_id (string), interpreted_goal (short string), selected_tools (array of tool names actually called), findings (array; each item has statement (string) and evidence_refs (array of source references)), limitations (array of strings), recommended_next_step (string), review_outcome (must be HUMAN_REVIEW_REQUIRED).
Evidence references must point to top-level fields in the actual tool results using syntax tool_name.field_name, for example get_temporal_activity.weekly_counts. Include at least one evidence reference for each finding. Include no unsupported numbers or claims. Do not make a credit decision. Do not use markdown fences or extra keys."""


def load_cases() -> list[dict[str, Any]]:
    return json.loads(CASES_FILE.read_text(encoding="utf-8"))


def get_case(case_id: str) -> dict[str, Any]:
    for case in load_cases():
        if case["case_id"] == case_id:
            return case
    raise KeyError(f"Unknown case_id: {case_id}")


def _base_url() -> str:
    return os.environ.get("LLM_BASE_URL", "https://openrouter.ai/api/v1").rstrip("/")


def _model() -> str:
    configured = os.environ.get("LLM_MODEL", "").strip()
    if configured:
        return configured
    if "openrouter.ai" in _base_url().lower():
        return "openrouter/free"
    raise RuntimeError("Set LLM_MODEL for the configured provider; no API request was made")


def _key() -> str:
    explicit = os.environ.get("LLM_API_KEY", "").strip()
    if explicit:
        return explicit
    if "openrouter.ai" in _base_url().lower():
        return os.environ.get("OPENROUTER_API_KEY", "").strip()
    if "api.openai.com" in _base_url().lower():
        return os.environ.get("OPENAI_API_KEY", "").strip()
    return ""


def _post(payload: dict[str, Any], timeout: int = 60) -> dict[str, Any]:
    key = _key()
    if not key:
        raise RuntimeError("Missing API key; no API request was made")
    body = {**payload, "model": _model(), "temperature": 0, "max_tokens": 900}
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    if "openrouter.ai" in _base_url().lower():
        headers["HTTP-Referer"] = os.environ.get("OPENROUTER_SITE_URL", "https://localhost/itxn-stage2")
        headers["X-Title"] = os.environ.get("OPENROUTER_APP_NAME", "ITXN Stage 2 Investigation Agent")
    req = urllib.request.Request(_base_url() + "/chat/completions", data=json.dumps(body).encode(), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read(500).decode("utf-8", errors="replace")
        raise RuntimeError(f"Provider HTTP {exc.code}: {detail}") from None
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Provider connection failed: {exc.reason}") from None


def _schemas() -> list[dict[str, Any]]:
    common = {"type": "string", "description": "Exact customer ID fixed by the explicit task; do not change it."}
    output = []
    for name, description in TOOL_DESCRIPTIONS.items():
        props: dict[str, Any] = {"customer_id": common}
        required = ["customer_id"]
        if name == "get_dimension_distribution":
            props["dimension"] = {"type": "string", "enum": sorted({"msgtype", "procode", "server_name", "token_requester", "token_trust_level"})}
            required.append("dimension")
        output.append({"type": "function", "function": {
            "name": name,
            "description": description,
            "parameters": {"type": "object", "properties": props, "required": required, "additionalProperties": False}
        }})
    return output


def _parse_json(content: str) -> dict[str, Any]:
    txt = (content or "").strip()
    txt = re.sub(r"^```(?:json)?\s*|\s*```$", "", txt, flags=re.I)
    obj = json.loads(txt)
    if not isinstance(obj, dict):
        raise ValueError("Final response must be a JSON object")
    return obj


def _leaf_refs(tool_results: dict[str, dict[str, Any]]) -> set[str]:
    refs: set[str] = set()
    for tool, result in tool_results.items():
        for key in result.keys():
            refs.add(f"{tool}.{key}")
    return refs


def validate_response(payload: dict[str, Any], case: dict[str, Any], tool_results: dict[str, dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    required_keys = {"case_id", "customer_id", "interpreted_goal", "selected_tools", "findings", "limitations", "recommended_next_step", "review_outcome"}
    if not isinstance(payload, dict):
        return ["response_not_object"]
    if set(payload) != required_keys:
        errors.append("wrong_output_keys")
    if payload.get("case_id") != case["case_id"]:
        errors.append("case_id_mismatch")
    if payload.get("customer_id") != case["customer_id"]:
        errors.append("customer_id_mismatch")
    if payload.get("review_outcome") != "HUMAN_REVIEW_REQUIRED":
        errors.append("unsafe_review_outcome")
    if not isinstance(payload.get("interpreted_goal"), str) or not payload.get("interpreted_goal", "").strip():
        errors.append("invalid_interpreted_goal")
    called = set(tool_results)
    selected = payload.get("selected_tools")
    if not isinstance(selected, list) or any(not isinstance(x, str) for x in selected) or len(selected) != len(set(selected)):
        errors.append("invalid_selected_tools")
    elif set(selected) != called:
        errors.append("selected_tools_do_not_match_executed_tools")
    findings = payload.get("findings")
    if not isinstance(findings, list) or not findings:
        errors.append("findings_missing")
    else:
        valid_refs = _leaf_refs(tool_results)
        for i, finding in enumerate(findings):
            if not isinstance(finding, dict) or set(finding) != {"statement", "evidence_refs"}:
                errors.append(f"finding_{i}_invalid_shape")
                continue
            if not isinstance(finding["statement"], str) or not finding["statement"].strip():
                errors.append(f"finding_{i}_empty_statement")
            refs = finding["evidence_refs"]
            if not isinstance(refs, list) or not refs or any((not isinstance(r, str) or r not in valid_refs) for r in refs):
                errors.append(f"finding_{i}_invalid_evidence_refs")
    if not isinstance(payload.get("limitations"), list) or any(not isinstance(x, str) for x in payload.get("limitations", [])):
        errors.append("invalid_limitations")
    if not isinstance(payload.get("recommended_next_step"), str) or not payload.get("recommended_next_step", "").strip():
        errors.append("invalid_next_step")
    return errors


def _usage(responses: list[dict[str, Any]]) -> dict[str, int | None]:
    usage = [r.get("usage") for r in responses if isinstance(r.get("usage"), dict)]
    if not usage:
        return {"prompt_tokens": None, "completion_tokens": None, "total_tokens": None}
    return {key: sum(int(u.get(key) or 0) for u in usage) for key in ("prompt_tokens", "completion_tokens", "total_tokens")}


def run_live(case_id: str, data_path: str | Path = DEFAULT_DATA, output_path: str | Path | None = None) -> dict[str, Any]:
    started = time.perf_counter()
    case = get_case(case_id)
    rows = load_rows(data_path)
    valid_ids = {r["synthetic_customer_id"].strip() for r in rows}
    if case["customer_id"] not in valid_ids:
        raise ValueError("Case points to an unknown synthetic customer")
    question = case["question_fa"]
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Case ID: {case_id}\nTarget customer (fixed): {case['customer_id']}\nQuestion: {question}\nSelect the minimum necessary read-only tools and answer the question."}
    ]
    first = _post({"messages": messages, "tools": _schemas(), "tool_choice": "auto", "parallel_tool_calls": True})
    choices = first.get("choices") or []
    if not choices:
        raise RuntimeError("No choice in tool-routing response; stopped without retry")
    assistant = choices[0].get("message") or {}
    calls = assistant.get("tool_calls") or []
    if not calls:
        raise RuntimeError("Model did not call a read-only tool; stopped without retry or second API request")
    if len(calls) > len(TOOL_FUNCTIONS):
        raise RuntimeError("Too many tool calls; stopped safely")
    tool_results: dict[str, dict[str, Any]] = {}
    tool_arguments: dict[str, dict[str, Any]] = {}
    normalized_calls: list[dict[str, Any]] = []
    for call in calls:
        func = call.get("function") or {}
        name = func.get("name")
        if name not in TOOL_FUNCTIONS:
            raise RuntimeError("Model requested a non-allowlisted tool; stopped safely")
        if name in tool_results:
            raise RuntimeError("Duplicate tool call rejected; stopped safely")
        try:
            args = json.loads(func.get("arguments") or "{}")
        except json.JSONDecodeError:
            raise RuntimeError("Malformed tool arguments; stopped safely") from None
        expected = {"customer_id"} if name != "get_dimension_distribution" else {"customer_id", "dimension"}
        if not isinstance(args, dict) or set(args) != expected or args.get("customer_id") != case["customer_id"]:
            raise RuntimeError("Unexpected tool arguments or target customer mismatch; stopped safely")
        result = execute_tool(name, args, case["customer_id"], data_path)
        tool_results[name] = result
        tool_arguments[name] = args
        normalized_calls.append(call)
    messages.append({"role": "assistant", "content": assistant.get("content"), "tool_calls": normalized_calls})
    for call in normalized_calls:
        name = call["function"]["name"]
        messages.append({"role": "tool", "tool_call_id": call.get("id"), "name": name, "content": json.dumps(tool_results[name], ensure_ascii=False)})
    second = _post({"messages": messages, "tool_choice": "none", "response_format": {"type": "json_object"}})
    choices2 = second.get("choices") or []
    if not choices2:
        raise RuntimeError("No choice in final response")
    payload = _parse_json((choices2[0].get("message") or {}).get("content", ""))
    errors = validate_response(payload, case, tool_results)
    used = list(tool_results)
    required_tools = set(case["required_tools"])
    selected_set = set(used)
    optional = set(case.get("optional_tools", []))
    expected_dimension = case.get("dimension")
    observed_dimension = tool_results.get("get_dimension_distribution", {}).get("dimension")
    argument_alignment = {
        "expected_dimension": expected_dimension,
        "observed_dimension": observed_dimension,
        "dimension_matches_case": (observed_dimension == expected_dimension) if expected_dimension else None,
    }
    tool_score = {
        "required_tools": sorted(required_tools),
        "executed_tools": used,
        "executed_tool_arguments": tool_arguments,
        "required_tool_recall": round(len(required_tools & selected_set) / len(required_tools), 4) if required_tools else 1.0,
        "tool_precision_against_case_allowlist": round(len(selected_set & (required_tools | optional)) / len(selected_set), 4) if selected_set else 0.0,
        "required_tools_all_used": required_tools <= selected_set,
        "extra_tool_calls_outside_case_allowlist": sorted(selected_set - required_tools - optional),
        "argument_alignment": argument_alignment,
    }
    report = {
        "study": "Stage 2 read-only investigation Agent: question-conditioned tool choice",
        "mode": "live_one_case",
        "case_id": case_id,
        "customer_id": case["customer_id"],
        "dataset": {"file": Path(data_path).name, "sha256": hashlib.sha256(Path(data_path).read_bytes()).hexdigest(), "synthetic_only": True},
        "protocol": {"api_requests_max": 2, "api_requests_used": 2, "automatic_retries": 0, "tools_available": sorted(TOOL_FUNCTIONS), "only_read_only_allowlisted_tools": True},
        "models_reported_by_provider": list(dict.fromkeys(x for x in [first.get("model"), second.get("model")] if isinstance(x, str))),
        "request_ids": [x for x in [first.get("id"), second.get("id")] if isinstance(x, str)],
        "usage_tokens": _usage([first, second]),
        "runtime_seconds": round(time.perf_counter() - started, 4),
        "question": case["question_fa"],
        "required_tools_gold": case["required_tools"],
        "optional_tools_gold": case.get("optional_tools", []),
        "gold_notes_for_manual_review": case.get("gold_notes", []),
        "expected_dimension_if_applicable": case.get("dimension"),
        "python_keyword_baseline_tools": route_question_python(case["question_fa"], case.get("dimension")),
        "agent_tool_score": tool_score,
        "tool_outputs": tool_results,
        "agent_payload": payload,
        "structural_and_evidence_reference_validation": {"status": "PASS" if not errors else "FAIL", "errors": errors},
        "interpretation_notes": [
            "This run measures question-conditioned read-only tool selection and evidence-referenced synthesis, not repayment prediction.",
            "Tool selection is scored automatically; factual/narrative quality still needs review against tool_outputs and gold_notes.",
            "A passing structure/evidence-reference check does not prove every natural-language claim is true.",
            "Only synthetic data may be sent to a third-party model API."
        ],
        "credit_decision_produced": False,
    }
    out = Path(output_path) if output_path else ROOT / "reports" / f"stage2_live_{case_id}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def route_question_python(question: str, dimension: str | None = None) -> list[str]:
    """Transparent keyword baseline; deliberately simple and independently testable."""
    q = (question or "").lower()
    selected: list[str] = []
    if any(x in q for x in ("تداوم", "پراکنده", "بازه", "زمان", "روند", "trend", "time", "continuity", "evenly")):
        selected.append("get_temporal_activity")
    if any(x in q for x in ("برگشت", "برگشتی", "reversal", "reverse", "پرچم برگشت")):
        selected.append("get_reversal_analysis")
    if any(x in q for x in ("سلامت", "شناسه تکراری", "کیفیت", "نقص", "integrity", "duplicate", "input health", "parseability")):
        selected.append("get_data_quality_report")
    if any(x in q for x in ("اجزای پردازش", "منبع", "سرور", "به تفکیک", "distribution", "server", "msgtype", "component")):
        selected.append("get_dimension_distribution")
    if any(x in q for x in ("توان پرداخت", "توان بازپرداخت", "درآمد", "اعتبار", "وام", "repayment", "income", "credit")):
        selected.append("get_activity_summary")
        # Static rule recognizes missing credit evidence but does not use transaction evidence to infer eligibility.
    if not selected:
        selected.append("get_activity_summary")
    # Keep order, remove duplicates.
    out = list(dict.fromkeys(selected))
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--mode", choices=["live"], required=True, help="Only live mode invokes the model API")
    ap.add_argument("--case", default="temporal_continuity", help="One case ID from cases.json")
    ap.add_argument("--data", default=str(DEFAULT_DATA))
    ap.add_argument("--output")
    args = ap.parse_args()
    result = run_live(args.case, args.data, args.output)
    print(json.dumps({
        "report": str(args.output or ROOT / "reports" / f"stage2_live_{args.case}.json"),
        "case_id": result["case_id"],
        "api_requests_used": result["protocol"]["api_requests_used"],
        "required_tools_gold": result["required_tools_gold"],
        "agent_tools": result["agent_tool_score"]["executed_tools"],
        "required_tool_recall": result["agent_tool_score"]["required_tool_recall"],
        "payload_validation": result["structural_and_evidence_reference_validation"]["status"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        raise SystemExit(f"Stage 2 stopped safely: {exc}")
