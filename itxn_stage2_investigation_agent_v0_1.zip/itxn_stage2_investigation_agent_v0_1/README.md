# Stage 2 read-only Investigation Agent v0.1

A bounded, tool-using LLM experiment on synthetic ITXN data. No write tools; one case per run; max two API requests and no automatic retries. See `README_FA.md` for Persian run steps.

Offline preflight and tests:

```bash
python stage2_evaluate.py
python -m unittest discover -s tests -v
```

Run exactly one live case only when you are ready to use your own provider key:

```bash
export OPENROUTER_API_KEY='your-key'
export LLM_BASE_URL='https://openrouter.ai/api/v1'
export LLM_MODEL='openrouter/free'
python stage2_agent.py --mode live --case temporal_continuity
```

Only synthetic data is permitted. Tool-selection accuracy and evidence-reference validity do not by themselves establish narrative truth or creditworthiness.
