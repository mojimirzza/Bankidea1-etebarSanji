"""Run the no-API baseline preflight for Stage 2; this does not simulate an LLM."""
from __future__ import annotations
import json, hashlib
from pathlib import Path
from stage2_agent import load_cases, route_question_python
from stage2_tools import DEFAULT_DATA, get_activity_summary, get_temporal_activity, get_reversal_analysis, get_data_quality_report, get_dimension_distribution

ROOT = Path(__file__).resolve().parent
TOOL_RUNNERS = {
    "get_activity_summary": get_activity_summary,
    "get_temporal_activity": get_temporal_activity,
    "get_reversal_analysis": get_reversal_analysis,
    "get_data_quality_report": get_data_quality_report,
}

def evaluate(data_path=DEFAULT_DATA):
    cases_out = []
    for case in load_cases():
        cust = case["customer_id"]
        baseline_tools = route_question_python(case["question_fa"], case.get("dimension"))
        # Gold expected tools are a rubric; the Python rule router is a baseline, not ground truth.
        required = set(case["required_tools"])
        selected = set(baseline_tools)
        cases_out.append({
            "case_id": case["case_id"], "customer_id": cust,
            "question_fa": case["question_fa"],
            "required_tools_gold": case["required_tools"],
            "python_keyword_baseline_tools": baseline_tools,
            "required_tool_recall": round(len(required & selected) / len(required), 4),
            "all_required_tools_selected": required <= selected,
            "gold_notes_for_manual_review": case["gold_notes"],
        })
    report = {
        "study": "Stage 2 baseline preflight — no model calls",
        "mode": "offline_python_keyword_baseline_only",
        "dataset": {"file": Path(data_path).name, "sha256": hashlib.sha256(Path(data_path).read_bytes()).hexdigest(), "synthetic_only": True},
        "case_count": len(cases_out),
        "api_calls": 0,
        "cases": cases_out,
        "warning": "This report evaluates only the transparent Python keyword-routing baseline. It does not evaluate an AI Agent and must not be described as an Agent result. Gold tool expectations require human review before benchmark use."
    }
    out = ROOT / "reports" / "stage2_baseline_preflight.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report

if __name__ == "__main__":
    r = evaluate()
    print(json.dumps({"report": str(ROOT / "reports" / "stage2_baseline_preflight.json"), "cases": r["case_count"], "api_calls": r["api_calls"], "baseline_required_tool_recall": round(sum(x["required_tool_recall"] for x in r["cases"]) / len(r["cases"]), 4)}, ensure_ascii=False, indent=2))
