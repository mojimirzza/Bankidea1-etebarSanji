"""Bounded, read-only investigation tools for synthetic ITXN records. Standard library only."""
from __future__ import annotations
import csv
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DEFAULT_DATA = ROOT / "synthetic_itxn.csv"
CREDIT_EVIDENCE_MISSING = ["REPAYMENT_HISTORY", "INCOME_OR_CASHFLOW", "EXISTING_OBLIGATIONS"]
ALLOWED_DIMENSIONS = {"msgtype", "procode", "server_name", "token_requester", "token_trust_level"}


def load_rows(path: str | Path = DEFAULT_DATA) -> list[dict[str, str]]:
    p = Path(path)
    with p.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        required = {"synthetic_customer_id", "refnum", "txnamt", "datein", "respcode", "rev_flag"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing required columns: " + ", ".join(sorted(missing)))
        rows = list(reader)
    if not rows:
        raise ValueError("Dataset is empty")
    return rows


def _truthy_flag(value: Any) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "y"}


def _number(value: Any) -> float | None:
    try:
        s = str(value).strip()
        return float(s) if s else None
    except (TypeError, ValueError):
        return None


def _date(value: Any) -> date | None:
    try:
        return datetime.strptime(str(value).strip(), "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def _customer_rows(customer_id: str, data_path: str | Path = DEFAULT_DATA) -> list[dict[str, str]]:
    if not isinstance(customer_id, str) or not customer_id.startswith("SYN-CUST-"):
        raise ValueError("Only explicit synthetic customer IDs are accepted")
    selected = [r for r in load_rows(data_path) if r.get("synthetic_customer_id", "").strip() == customer_id]
    if not selected:
        raise KeyError(f"Unknown synthetic customer: {customer_id}")
    return selected


def get_activity_summary(customer_id: str, data_path: str | Path = DEFAULT_DATA) -> dict[str, Any]:
    rows = _customer_rows(customer_id, data_path)
    amounts = [_number(r.get("txnamt")) for r in rows]
    valid_amounts = [v for v in amounts if v is not None]
    active_dates = sorted({r.get("datein", "").strip() for r in rows if _date(r.get("datein"))})
    codes = [str(r.get("respcode") or "").strip() for r in rows if str(r.get("respcode") or "").strip()]
    # The synthetic generator's code "00" is treated as success for this experiment only.
    success_count = sum(code == "00" for code in codes)
    reversal_count = sum(_truthy_flag(r.get("rev_flag")) for r in rows)
    return {
        "customer_id": customer_id,
        "txn_count": len(rows),
        "active_days_observed": len(active_dates),
        "first_observed_date": min(active_dates) if active_dates else None,
        "last_observed_date": max(active_dates) if active_dates else None,
        "amount_valid_count": len(valid_amounts),
        "amount_validity_rate": round(len(valid_amounts) / len(rows), 4),
        "amount_sum_observed": round(sum(valid_amounts), 2),
        "amount_avg_observed": round(sum(valid_amounts) / len(valid_amounts), 2) if valid_amounts else None,
        "reversal_count": reversal_count,
        "reversal_rate": round(reversal_count / len(rows), 4),
        "known_response_code_count": len(codes),
        "response_code_coverage": round(len(codes) / len(rows), 4),
        "success_count_under_synthetic_code_convention": success_count,
        "success_rate_among_known_codes_under_synthetic_code_convention": round(success_count / len(codes), 4) if codes else None,
        "missing_credit_evidence": list(CREDIT_EVIDENCE_MISSING),
        "interpretation_boundary": "Observed ITXN activity is not proof of income, repayment history, or repayment capacity."
    }


def get_temporal_activity(customer_id: str, data_path: str | Path = DEFAULT_DATA) -> dict[str, Any]:
    rows = _customer_rows(customer_id, data_path)
    dated = [(d, r) for r in rows if (d := _date(r.get("datein"))) is not None]
    if not dated:
        return {"customer_id": customer_id, "dated_row_count": 0, "period_start": None, "period_end": None, "weekly_counts": [], "first_half_txn_count": 0, "second_half_txn_count": 0, "half_period_change_pct": None}
    dates = [d for d, _ in dated]
    start, end = min(dates), max(dates)
    midpoint = start + timedelta(days=(end - start).days // 2)
    first_half = [(d, r) for d, r in dated if d <= midpoint]
    second_half = [(d, r) for d, r in dated if d > midpoint]
    weekly: dict[str, int] = defaultdict(int)
    for d, _ in dated:
        iso = d.isocalendar()
        weekly[f"{iso.year}-W{iso.week:02d}"] += 1
    first_count, second_count = len(first_half), len(second_half)
    change_pct = None if first_count == 0 else round(((second_count - first_count) / first_count) * 100, 2)
    if change_pct is None:
        trend = "NOT_ASSESSABLE"
    elif change_pct >= 20:
        trend = "MORE_ROWS_IN_SECOND_CALENDAR_HALF"
    elif change_pct <= -20:
        trend = "FEWER_ROWS_IN_SECOND_CALENDAR_HALF"
    else:
        trend = "SIMILAR_ROW_COUNTS_ACROSS_HALVES"
    return {
        "customer_id": customer_id,
        "dated_row_count": len(dated),
        "period_start": start.isoformat(),
        "period_end": end.isoformat(),
        "split_date_inclusive_for_first_half": midpoint.isoformat(),
        "first_half_txn_count": first_count,
        "second_half_txn_count": second_count,
        "half_period_change_pct": change_pct,
        "count_comparison_label": trend,
        "weekly_counts": [{"iso_week": k, "txn_count": weekly[k]} for k in sorted(weekly)],
        "interpretation_boundary": "Counts describe the observed dataset and do not establish cause, income, or repayment capacity."
    }


def get_reversal_analysis(customer_id: str, data_path: str | Path = DEFAULT_DATA) -> dict[str, Any]:
    rows = _customer_rows(customer_id, data_path)
    reversals = [r for r in rows if _truthy_flag(r.get("rev_flag"))]
    msg_counts = Counter(str(r.get("msgtype") or "UNKNOWN") for r in reversals)
    examples = []
    for r in sorted(reversals, key=lambda x: (x.get("datein", ""), x.get("refnum", "")))[:10]:
        examples.append({
            "datein": r.get("datein"),
            "refnum": r.get("refnum"),
            "msgtype": r.get("msgtype"),
            "txnamt": _number(r.get("txnamt")),
            "server_name": r.get("server_name"),
        })
    return {
        "customer_id": customer_id,
        "txn_count": len(rows),
        "reversal_count": len(reversals),
        "reversal_rate": round(len(reversals) / len(rows), 4),
        "reversals_by_msgtype": dict(sorted(msg_counts.items())),
        "example_rows_max_10": examples,
        "interpretation_boundary": "rev_flag is an observed marker only; this tool does not infer why a reversal occurred or any credit risk."
    }


def get_data_quality_report(customer_id: str, data_path: str | Path = DEFAULT_DATA) -> dict[str, Any]:
    rows = _customer_rows(customer_id, data_path)
    checked_fields = ["refnum", "msgtype", "procode", "txnamt", "datein", "respcode", "rev_flag", "server_name"]
    missing_counts = {
        field: sum(1 for r in rows if str(r.get(field) or "").strip() == "")
        for field in checked_fields
    }
    refnums = [str(r.get("refnum") or "").strip() for r in rows if str(r.get("refnum") or "").strip()]
    valid_amounts = sum(_number(r.get("txnamt")) is not None for r in rows)
    valid_dates = sum(_date(r.get("datein")) is not None for r in rows)
    response_codes = sum(str(r.get("respcode") or "").strip() != "" for r in rows)
    dup_counts = Counter(refnums)
    duplicate_refnum_values = sorted(k for k, n in dup_counts.items() if n > 1)
    return {
        "customer_id": customer_id,
        "row_count": len(rows),
        "checked_fields": checked_fields,
        "blank_counts_by_field": missing_counts,
        "valid_amount_count": valid_amounts,
        "invalid_amount_count": len(rows) - valid_amounts,
        "valid_datein_count": valid_dates,
        "invalid_datein_count": len(rows) - valid_dates,
        "response_code_coverage": round(response_codes / len(rows), 4),
        "nonblank_refnum_count": len(refnums),
        "duplicate_refnum_row_count": sum(n - 1 for n in dup_counts.values() if n > 1),
        "duplicate_refnum_values_max_10": duplicate_refnum_values[:10],
        "scope_note": "This is a limited field-level check, not a complete source-system reconciliation or business-semantic validation."
    }


def get_dimension_distribution(customer_id: str, dimension: str, data_path: str | Path = DEFAULT_DATA) -> dict[str, Any]:
    if dimension not in ALLOWED_DIMENSIONS:
        raise ValueError(f"Unsupported dimension. Allowed: {', '.join(sorted(ALLOWED_DIMENSIONS))}")
    rows = _customer_rows(customer_id, data_path)
    counts = Counter(str(r.get(dimension) or "<BLANK>").strip() or "<BLANK>" for r in rows)
    return {
        "customer_id": customer_id,
        "dimension": dimension,
        "row_count": len(rows),
        "distinct_value_count": len(counts),
        "distribution": [
            {"value": value, "count": count, "share": round(count / len(rows), 4)}
            for value, count in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
        ],
        "interpretation_boundary": "This is a descriptive distribution only and is not a risk score."
    }


TOOL_FUNCTIONS = {
    "get_activity_summary": get_activity_summary,
    "get_temporal_activity": get_temporal_activity,
    "get_reversal_analysis": get_reversal_analysis,
    "get_data_quality_report": get_data_quality_report,
    "get_dimension_distribution": get_dimension_distribution,
}


def execute_tool(name: str, arguments: dict[str, Any], customer_id: str, data_path: str | Path = DEFAULT_DATA) -> dict[str, Any]:
    if name not in TOOL_FUNCTIONS:
        raise ValueError("Tool is not allowlisted")
    if not isinstance(arguments, dict) or arguments.get("customer_id") != customer_id:
        raise ValueError("Tool arguments must reference the explicit target customer")
    allowed_args = {"customer_id", "dimension"} if name == "get_dimension_distribution" else {"customer_id"}
    if set(arguments) != allowed_args:
        raise ValueError("Unexpected or missing tool arguments")
    fn = TOOL_FUNCTIONS[name]
    if name == "get_dimension_distribution":
        return fn(customer_id, arguments["dimension"], data_path)
    return fn(customer_id, data_path)
